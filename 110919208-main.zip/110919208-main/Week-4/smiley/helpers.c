#include "helpers.h"

void colorize(int height, int width, RGBTRIPLE image[height][width])
{
    // Change all black pixels to a color of your choosing
    for (int i = 0; height > i; i++)
    {
        for (int j = 0; width > j; j++)
        {
            if (image[i][j].rgbtBlue == 255 || image[i][j].rgbtGreen == 255 || image[i][j].rgbtRed == 255)
            {
                image[i][j].rgbtBlue = 71;
                image[i][j].rgbtGreen = 76;
                image[i][j].rgbtRed = 30;
            }
        }
    }
}