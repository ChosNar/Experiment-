#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "wav.h"

int check_format(WAVHEADER header);
int get_block_size(WAVHEADER header);
void end(FILE *oupr, FILE *inpr);
int main(int argc, char *argv[])
{
    // Ensure proper usage
    // TODO #1
    if (argc != 3)
    {
        printf("Please provide program name, input file, & output\n");
        return 1;
    }
    // Open input file for reading
    // TODO #2
    char *infy = argv[1];
    FILE *inpr = fopen(infy, "rb");
    if (inpr == NULL)
    {
        printf("File open error %s.\n", infy);
        end(NULL, inpr);
        // fclose(inpr);
        return 1;
    }
    // Read header
    // TODO #3
    WAVHEADER header;
    fread(&header, sizeof(WAVHEADER), 1, inpr);
    // Use check_format to ensure WAV format
    // TODO #4
    if (check_format(header) == 0)
    {
        printf("This isn't a WAV file\n");
        end(NULL, inpr);
        // fclose(inpr);
        return 1;
    }
    // it is also possible to check that the audio format is = 1
    // if(header.audioFormat != 1)
    //{
    //  printf("This isn't a WAV file\n");
    //  fclose(inpr);
    //  return 1;
    //  }
    // Open output file for writing
    // TODO #5
    char *oufy = argv[2];
    FILE *oupr = fopen(oufy, "wb");
    if (oupr == NULL)
    {
        printf("File open error %s.\n", oufy);
        end(oupr, inpr);
        // fclose(oupr);
        // fclose(inpr);
        return 1;
    }
    // Write header to file
    // TODO #6
    fwrite(&header, sizeof(WAVHEADER), 1, oupr);
    // Use get_block_size to calculate size of block
    // TODO #7
    int size = get_block_size(header);
    // Write reversed audio to file
    // TODO #8
    if (fseek(inpr, size, SEEK_END))
    {
        end(oupr, inpr);
        // fclose(oupr);
        // fclose(inpr);
        return 1;
    }
    BYTE buffer[size];
    while (ftell(inpr) - size > sizeof(header))
    {
        if (fseek(inpr, -2 * size, SEEK_CUR))
        {
            end(oupr, inpr);
            // fclose(oupr);
            // fclose(inpr);
            return 1;
        }
        fread(buffer, size, 1, inpr);
        fwrite(buffer, size, 1, oupr);
    }
    end(oupr, inpr);
    // fclose(oupr);
    // fclose(inpr);
}

int check_format(WAVHEADER header)
{
    // TODO #4
    if (header.format[0] == 'W' && header.format[1] == 'A' && header.format[2] == 'V' && header.format[3] == 'E')
    {
        return 1;
    }
    return 0;
}

int get_block_size(WAVHEADER header)
{
    // TODO #7
    int bsize = header.numChannels * (header.bitsPerSample / 8);
    return bsize;
}
void end(FILE *oupr, FILE *inpr)
{
    if (oupr != NULL)
    {
        fclose(oupr);
    }
    if (inpr != NULL)
    {
        fclose(inpr);
    }
}