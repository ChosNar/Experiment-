#include "helpers.h"
#include "math.h"

#define BC 0
#define GC 1
#define RC 2

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    {
        // Avarage the coloration of each pixle
        for (int i = 0; height > i; i++)
        {
            for (int j = 0; width > j; j++)
            {
                int gray = rint((image[i][j].rgbtBlue + image[i][j].rgbtGreen + image[i][j].rgbtRed) / 3.0);
                image[i][j].rgbtBlue = gray;
                image[i][j].rgbtGreen = gray;
                image[i][j].rgbtRed = gray;
            }
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    // make a place holder
    RGBTRIPLE pl;
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width / 2; j++)
        {
            pl = image[i][j];
            image[i][j] = image[i][width - j - 1];
            image[i][width - j - 1] = pl;
        }
    }
    return;
}

// Blur image
int getBlur(int x, int y, int hight, int width, RGBTRIPLE image[hight][width], int color_position)
{
    float count = 0;
    int sum = 0;
    for (int i = x - 1; i <= x + 1; i++)
    {
        for (int j = y - 1; j <= y + 1; j++)
        {
            if (i >= 0 && j >= 0 && i < hight && j < width)
            {
                if (color_position == BC)
                {
                    sum += image[i][j].rgbtBlue;
                }
                else if (color_position == GC)
                {
                    sum += image[i][j].rgbtGreen;
                }
                else
                {
                    sum += image[i][j].rgbtRed;
                }
                count++;
            }
        }
    }
    return round(sum / count);
}
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    // make a place holder copy
    RGBTRIPLE du[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            du[i][j] = image[i][j];
        }
    }
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j].rgbtBlue = getBlur(i, j, height, width, du, BC);
            image[i][j].rgbtGreen = getBlur(i, j, height, width, du, GC);
            image[i][j].rgbtRed = getBlur(i, j, height, width, du, RC);
        }
    }
    return;
}
// Sobel kernels for edge detection in horizontal and vertical directions
int sobel_horizontal[3][3] = {{-1, 0, 1}, {-2, 0, 2}, {-1, 0, 1}};
int sobel_vertical[3][3] = {{-1, -2, -1}, {0, 0, 0}, {1, 2, 1}};
int norm(int pixle_value)
{
    if (cdpixle_value > 255)
    {
        return 255;
    }
    else if (pixle_value < 0)
    {
        return 0;
    }
    return pixle_value;
}

// Apply Sobel filter to a pixel using the given kernel
int apply_sobel_filter(int x, int y, int height, int width, RGBTRIPLE image[height][width], int color_position, int kernel[3][3])
{
    int sum_x = 0;
    int sum_y = 0;

    for (int i = -1; i <= 1; i++)
    {
        for (int j = -1; j <= 1; j++)
        {
            int new_x = x + i;
            int new_y = y + j;

            if (new_x >= 0 && new_x < height && new_y >= 0 && new_y < width)
            {
                int pixel_value = 0;

                if (color_position == BC)
                {
                    pixel_value = image[new_x][new_y].rgbtBlue;
                }
                else if (color_position == GC)
                {
                    pixel_value = image[new_x][new_y].rgbtGreen;
                }
                else
                {
                    pixel_value = image[new_x][new_y].rgbtRed;
                }

                sum_x += kernel[i + 1][j + 1] * pixel_value;
                sum_y += kernel[j + 1][i + 1] * pixel_value;
            }
            // Not needed redundent
            //  else
            //  {
            //      // Handle pixels outside the image by treating them as 0
            //      sum_x += 0;
            //      sum_y += 0;
            //  }
        }
    }
    int sobel_value = rint(sqrt(sum_x * sum_x + sum_y * sum_y));
    return norm(sobel_value);
}

// Create a copy of the original image
void edges(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE du[height][width]; // Placeholder copy of the image

    // Create a copy of the original image
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            du[i][j] = image[i][j];
        }
    }
    // Apply Sobel edge detection to each pixel
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j].rgbtBlue = apply_sobel_filter(i, j, height, width, du, BC, sobel_horizontal);

            image[i][j].rgbtGreen = apply_sobel_filter(i, j, height, width, du, GC, sobel_horizontal);

            image[i][j].rgbtRed = apply_sobel_filter(i, j, height, width, du, RC, sobel_horizontal);
        }
    }
    return;
}