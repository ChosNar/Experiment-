// Implements a dictionary's functionality

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#include "dictionary.h"

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
} node;

// TODO: Choose number of buckets in hash table
const unsigned int N = 26;

// Hash table
node *table[N];

unsigned int hshvl;
unsigned int wcnt;
// Returns true if word is in dictionary, else false
bool check(const char *word)
{
    hshvl = hash(word);
    node *n = table[hshvl];
    while (n != NULL)
    {
        if (strcasecmp(n->word, word) == 0)
        {
            return 1;
        }
        n = n->next;
    }
    // TODO
    return false;
}

// Hashes word to a number
unsigned int hash(const char *word)
{
    // TODO: Improve this hash function
    // return toupper(word[0]) - 'A';
    unsigned long t = 0;
    for (int i = 0; i < strlen(word); i++)
    {
        t += tolower(word[i]);
    }
    return t % N;
}

// Loads dictionary into memory, returning true if successful, else false
bool load(const char *dictionary)
{
    FILE *file = fopen(dictionary, "r");
    // TODO
    // Load file
    if (file == NULL)
    {
        printf("unable to open %s \n", dictionary);
        return false;
    }
    // Declare Var
    char wrd[LENGTH + 1];
    // scn till EOF
    while (fscanf(file, "%s", wrd) != EOF)
    {
        // Memory allocation
        node *ch = malloc(sizeof(node));
        // errors remember...
        if (ch == NULL)
        {
            return false;
        }
        // copy dict word into node
        strcpy(ch->word, wrd);
        hshvl = hash(wrd);
        // is this if even needed?
        if (table[hshvl] == NULL)
        {
            ch->next = NULL;
        }
        else
        {
            ch->next = table[hshvl];
        }
        table[hshvl] = ch;
        wcnt++;
    }
    fclose(file);
    return 1;
}

// Returns number of words in dictionary if loaded, else 0 if not yet loaded
unsigned int size(void)
{
    // TODO
    if (wcnt > 0)
    {
        return wcnt;
    }
    return 0;
}
void freenode(node *n)
{
    if (n->next != NULL)
    {
        freenode(n->next);
    }
    free(n);
    // -------
    // if (n == NULL)
    // {
    //     return;
    // }
    // // Recursively free the rest of the list
    // freenode(n->next);
    // // Free the word
    // free(n->word);
    // // Free the node
    // free(n);
}
//  Unloads dictionary from memory, returning true if successful, else false
bool unload(void)
{
    // TODO
    for (int i = 0; i < N; i++)
    {
        if (table[i] != NULL)
        {
            freenode(table[i]);
        }
        //---------

        // if (table[i] != NULL)
        // {
        //     freenode(table[i]);
        //     table[i] = NULL;
        //     // Set the table to NULL after freeing the list
        // }

        // -------
        // figure out error here:
        //     node *crsr = table[i];
        //     if (crsr != NULL)
        //     {
        //         while (crsr)
        //         {
        //             node *tp = crsr;
        //             crsr = crsr->next;
        //             free(tp->word);
        //             free(tp);
        //         }
        //         if (crsr == NULL)
        //         {
        //             return true;
        //         }
        //     }
    }
    return true;
}
