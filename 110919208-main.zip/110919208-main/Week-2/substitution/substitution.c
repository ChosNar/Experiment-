#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
string txt;
int main(int argc, string argv[])
{
    if (argc != 2)
    {
        printf("Usage: ./substitution key\n");
        return 1;
    }
    // cyph key length (could me made int a truth var)
    string error = "The cypher key needs to be 26, distinct, alphabetical characters long\n", ck = argv[1];
    if (strlen(ck) != 26)
    {
        printf("%s", error);
        return 1;
    }
    for (int cp = 0; cp < strlen(ck); cp++)
    {
        if (!isalpha(ck[cp]))
        {
            printf("%s", error);
            return 1;
        }
        //Checking for duplicated Chars
        for (int cd = cp + 1; cd < strlen(ck); cd++)
        {
            if (toupper(ck[cp]) == toupper(ck[cd]))
            {
                printf("%s", error);
                return 1;
            }
        }
    }
    //Text valuation
    txt = get_string("plaintext: ");
    for (int cap = 0; cap < strlen(ck); cap++)
    {
        if (!isupper(ck[cap]))
        {
            ck[cap] = toupper(ck[cap]);
        }
    }
    printf("ciphertext: ");
    int cl;
    for (int tc = 0; tc < strlen(txt); tc++)
    {
        if (isupper(txt[tc]))
        {
            cl = txt[tc] - 'A';
            printf("%c", ck[cl]);
        }
        else if (islower(txt[tc]))
        {
            cl = txt[tc] - 'a';
            printf("%c", tolower(ck[cl]));
        }
        else
        {
            printf("%c", txt[tc]);
        }
    }
    printf("\n");
    return 0;
}