#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

int cc(string text);
int main(void)
{
    string text = get_string("Text: ");
    int lc = 0, sc = 0, wc = 1;
    for (int i = 0, l = strlen(text); i < l; i++)
    {
        if ((isupper(text[i])) || (islower(text[i])))
        {
            lc ++;
        }
        else if ((text[i]) == '.' || (text[i]) == '!' || (text[i]) == '?')
        {
            sc ++;
        }
        else if (isblank(text[i]))
        {
            wc ++;
        }
    }
    float cal = (0.0588 * lc / wc * 100) - (0.296 * sc / wc * 100) - 15.8;
    int g = round(cal);
    if (g < 1)
    {
        printf("Before Grade 1\n");
        return 0;
    }
    else if (g > 15)
    {
        printf("Grade 16+\n");
        return 0;
    }
    else
    {
        printf("Grade %i\n", g);
    }
}