$(document).ready(function() {
  $(window).scroll(function() {
  consol.log("scrolling!")
    $('.title').removeClass('title').addClass('defu');
  });

  $('.menu').hover(function() {
    $(this).toggleClass('open');
  });

  $(".map").load("map.html");
});
