import re


def main():
    card_number = input("Please enter your card number: ")

    # Check if the input matches the pattern for a card number
    if re.match(r"^(3[47]\d{13}|4\d{12}(\d{3})?|5[1-5]\d{14})$", card_number):
        # ^:start, $:end
        # Amex ^3 followed by 4/7 and has 15 digits (hence \d{} 12 for 12 following digits)
        # Visa ^4 and has 13 or 16 digits (\d{12}(\{3})?)
            # ? makes the precedent optional hens(\d{3})
        # or
        # MasCard ^5 followed by a digit from 1-5 and has 16 digits in total
        # Verification
        digits = [int(digit) for digit in card_number[::-1]]
        for i in range(1, len(digits), 2):
            digits[i] *= 2
            digits[i] = digits[i] % 10 + digits[i] // 10

        if sum(digits) % 10 == 0:
            if card_number.startswith("34") or card_number.startswith("37"):
                print("AMEX")
            elif card_number.startswith("4"):
                print("VISA")
            elif card_number.startswith(("51", "52", "53", "54", "55")):
                print("MASTERCARD")
            else:
                print("INVALID")
        else:
            print("INVALID")
    else:
        print("INVALID")


if __name__ == "__main__":
    main()


# Something is wrong here
# from cs50 import get_int

# def main():
#     n = get_int("Please enter your card number: ")

#     #Card placements and size
#     z = 0
#     c = [0] * 16  # Initialize an array to store card digits

#     #Copy the digits of n into the array c
#     for i in range(16):
#         c[i] = n % 10
#         n //= 10
#         z += 1
#         if n == 0:
#             break

#     #Check for any 10s
#     for i in range(1, 16, 2):
#         c[i] *= 2
#         c[i] = c[i] % 10 + c[i] // 10

#     #Verification
#     if sum(c) % 10 != 0:
#         print("INVALID")
#         return

#     #How many placements does it have?
#     a = c[0]
#     v = c[0]
#     m = c[0]

#     #Which card type is it?
#     if z == 15 and (a == 3 or a == 7):
#         print("AMEX")
#     elif (z == 13 or z == 16) and v == 4:
#         print("VISA")
#     elif z == 16 and (m == 5 or (m >= 1 and m <= 5)):
#         print("MASTERCARD")
#     else:
#         print("INVALID")

# if __name__ == "__main__":
#     main()
