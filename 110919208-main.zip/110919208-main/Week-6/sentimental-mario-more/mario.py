# TODO
from cs50 import get_int


def main():
    h = get_height()
    s = h - 1
    for i in range(1, h + 1):
        print(" " * s, end="")
        s -= 1
        print("#" * i, end="  ")
        print("#" * i)


def get_height():
    while True:
        n = get_int("Height: ")
        if n > 0 and n < 9:
            return n
        else:
            print("Hight can not be over 8 or under 1")


main()

# def main():
#     h = get_height()
#     s = h - 1
#     for i in range(1, h):
#         print(" " * s, end="")
#         s -= 1
#         print("#" * i, end="  ")
#         print("#" * i)

# def get_height():
#     while True:
#         n = get_int("Height: ")
#         if n > 0 and n < 9:
#             return n + 1
#         else:
#             print("Height cannot be over 8 or under 1")

# Why is it that the if the example input: Height = 4
# Output:
#    #  #
#   ##  ##
#  ###  ###