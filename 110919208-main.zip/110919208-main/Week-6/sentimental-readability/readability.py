import math


def main():
    text = input("Text: ")
    result = cc(text)
    print(result)


# you don't really need to sep. this
def cc(text):
    lc, sc, wc = 0, 0, 1

    for char in text:
        if char.isalpha():
            lc += 1
        elif char in [".", "!", "?"]:
            sc += 1
        elif char.isspace():
            wc += 1

    cal = (0.0588 * lc / wc * 100) - (0.296 * sc / wc * 100) - 15.8
    g = round(cal)

    if g < 1:
        return "Before Grade 1"
    elif g > 15:
        return "Grade 16+"
    else:
        return f"Grade {g}"


if __name__ == "__main__":
    main()
